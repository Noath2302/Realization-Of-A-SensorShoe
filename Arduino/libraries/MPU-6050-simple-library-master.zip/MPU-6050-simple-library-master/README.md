# MPU-6050-simple-library
This is a very simple library to handle the communication between your Arduino and the IMU (Inertial Measurement Unit) module MPU-6050. It is shown an example on how to use it.
