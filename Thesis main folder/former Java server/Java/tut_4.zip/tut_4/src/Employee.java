public class Employee {
    private String name;
    private String Department;
    private int ID;
    private Double Salary,BaseSalary;
    public Employee(String name, int ID, String Department){
        this.name = name;
        this.Department = Department;
        this.ID   = ID  ;
    }

    public void printData(){
        System.out.println(name+" "+ID+" "+Department+" "+Salary);
    }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDepartment() { return Department; }
    public void setDepartment(String department) { Department = department; }
    public int getID() { return ID; }
    public void setID(int ID) { this.ID = ID; }
    public Double getSalary() { return Salary; }
    public void setSalary(Double salary) { Salary = salary; }
    public void setBaseSalary(Double baseSalary) { BaseSalary = baseSalary; }
    public Double getBaseSalary() { return BaseSalary; }
}
