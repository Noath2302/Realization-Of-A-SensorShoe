public class Apprentice extends Employee {
    Date startDate,endDate;

    public Apprentice(String name, int ID, String Department){
        super(name,ID,Department);
    }
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    public Date getStartDate() {
        return startDate;
    }
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    public Date getEndDate() {
        return endDate;
    }

}
