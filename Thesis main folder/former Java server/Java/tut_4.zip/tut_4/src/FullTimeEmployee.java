public class FullTimeEmployee extends Employee {
    int allowedDayOff;
    public FullTimeEmployee(String name,int ID, String Department){
        super(name,ID,Department);
    }
    public void setSalary(Date date) {
        if (allowedDayOff >= 0) {
            if (date.getMonth() == 12) {
                super.setSalary(getBaseSalary() * 1.5);
            }
            else setSalary(getBaseSalary());
        }
        else if (allowedDayOff>-2){
            super.setSalary(getSalary()*0.5);
        }
        else super.setSalary(0.0);
    }

}
